#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
typedef uint8_t BYTE;

int main(int argc, char *argv[])
{
    if(argc != 2)
     {
        printf("usage : ./recover input.file");
        return 1;
     }
  FILE *input =fopen(argv[1],"r");
  if(input == NULL)
  {
     printf("input file can't be opened");
     return 1;
  }

  BYTE buffer[512];
  int r =0;
  char name[50];
  FILE *output[60];
  output[0] =fopen("dummy.jpeg","w");
  if(output[0] == NULL)
    {
       printf("output file can't be opened");
       return 1;
    }
    int i =0;

  while(fread(&buffer, sizeof(BYTE), 512 ,input)== 512)
  {
      if(buffer[0]==0xff && buffer[1]==0xd8 && buffer[2]==0xff && (buffer[3] & 0xf0)==0xe0)
      {
          i++;
          fclose(output[i - 1]);
          sprintf(*&name,"%03i.jpg",*&r);
          *&r=r + 1;
          output[i] =fopen(name,"a");
          if(output[i] == NULL)
           {
             printf("output file can't be opened");
             return 1;
           }

          fwrite(&buffer, sizeof(BYTE), 512 ,output[i]);
      }
      else
      {


          fwrite(&buffer, sizeof(BYTE), 512 ,output[i]);

      }




    }
    fclose(input);
    fclose(output[i]);


  }








